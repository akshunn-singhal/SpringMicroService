package com.harman.collateral.processor.dto;

public record ErrorResponse(String errorMsg) {
}
