package com.harman.collateral.processor.dto;

public record CollateralResponse(long collateralId, CollateralDetails collaterals) {
}