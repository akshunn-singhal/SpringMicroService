package com.harman.collateral.processor.dto;

import com.harman.collateral.processor.entity.CollateralCashDeposits;
import com.harman.collateral.processor.entity.CollateralRealEstate;

public enum CollateralTypeEnum {
    CASH(CollateralCashDeposits.class),
    REAL_ESTATE(CollateralRealEstate.class);

    private final Class className;

    private CollateralTypeEnum(Class c) {
        this.className = c;
    }

    public Class getClassName() {
        return this.className;
    }
}
